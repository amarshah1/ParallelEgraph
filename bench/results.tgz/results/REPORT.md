# ParallelEgraph BSP Congruence-Closure — High-Core-Count Evaluation

Single benchmark session on a 144-core (4-socket Intel Xeon E7-8867 v4 @ 2.40 GHz, 4 NUMA nodes, 1 TiB DDR4) Linux box. All artifacts in `bench/results/`; tarball at `bench/results.tgz`.

## Build & system

- `cmake -B build -S . -DCMAKE_BUILD_TYPE=Release` + `cmake --build build -j` clean. `ctest` 2/2 pass.
- Compiler: g++ 9.4.0; CMake 3.28.0.
- Parlay scheduler with `PARLAY_ELASTIC_PARALLELISM=true` (default) and `PARLAY_ELASTIC_STEAL_TIMEOUT=10000` µs (default).
- One workaround: `gen_bench.py` uses Python ≥ 3.9 syntax; `bench/scripts/run.py` invokes `sys.executable` (3.8 here). SMT step run with `python3.10 bench/scripts/run.py smt …`.

## Strong-scaling — baseline workloads (T=1, 16, 64, 144)

```
workload    nelson      T=1     T=16     T=64    T=144  spd_T1 spd_nel  eff
small         3.97     4.23     1.94     3.17     4.54   0.93×   0.87×  0.006
medium      103.79   150.35    17.62    18.17    17.73   8.48×   5.85×  0.041
large      1006.94  1179.26   112.18    72.80    59.93  19.68×  16.80×  0.117
deep-s        6.74    12.11     4.21     5.57     6.08   1.99×   1.11×  0.008
deep-m      130.82   132.59    17.98    16.61    17.57   7.54×   7.44×  0.052
deep-l     1115.73  1086.16    95.84    62.82    47.34  22.95×  23.57×  0.164
```

- `small` and `medium` plateau early or regress — parallel overhead exceeds work.
- `deep-l` (depth=3) outscales `large` (depth=1) at the same width: more BSP rounds amortize barrier and warm-up costs.

## Width × depth grid — pushing both axes

`PE_BENCH_CUSTOM=leaves,fns,nodes,merges,depth` lets us define arbitrary workloads without source edits. Width labels: `large` (50k leaves), `xl` (100k), `2xl` (200k), `4xl` (400k); nodes/merges scale 1:1.

```
Speedup T=1 → T=144      d=1     d=3     d=5     d=7
large                  19.68×  22.95×    -       -
xl                     22.55×  26.37×  23.86×  18.91×
2xl                    30.19×  30.24×  25.64×    -
4xl                       -    36.83×    -       -

Efficiency               d=1    d=3    d=5    d=7
large                  0.137  0.159    -      -
xl                     0.157  0.183  0.166  0.131
2xl                    0.210  0.210  0.178    -
4xl                       -   0.256    -      -
```

Two distinct shapes:

- **Width axis: monotone climb, no plateau yet.** Each doubling at d=3 lifts efficiency 0.024 → 0.027 → 0.046 (incrementally accelerating). 4xl-d3 hits 36.83× T=1→T=144 / 43.36× over nelson.
- **Depth axis: peak at d=3, then collapse.** xl: 0.157 → 0.183 → 0.166 → 0.131. Past d=3, deeper graphs have *less* sequential CC work to parallelize (xl-d7 nelson is faster than xl-d1).

The user's prior 35× speedup-over-baseline number is matched/exceeded across the d=3 column (xl-d3: 44×, 4xl-d3: 43×).

## Round-level decomposition (trace bench, T=144)

```
large   round 0: total 50.11 ms   semisort 46.31 (group_by 26.71, 53% of round)
        round 1: total 12.85 ms   consolidate 9.20

deep-l  round 0: total 18.74 ms   semisort 16.16
        round 1: total 16.78 ms
        round 2: total 15.74 ms
        round 3: total  1.19 ms
```

`group_by_key` owns 53% of round 0 on `large` (the user's prior 12-core data showed ~40%). `semisort` overall is 92% of round 0.

## Component bench (consolidate vs semisort scaling)

```
phase           T=1      T=16    T=64    T=144   spd
consolidate     22.11    2.43    1.49    1.35   16.33×
semisort       673.55   57.70   33.61   33.87   19.89× (saturated past T=64)
```

`consolidate` keeps scaling well past T=8 (the user's prior 12-core ceiling at 4.5×). `semisort` is the wall — saturated between T=64 and T=144.

## Tunable sweeps (xl, T=144, large)

```
union_style:    adjacent 61.61 ms   |   dnc 67.25 ms       (adjacent ~9% faster)
dnc_cutoff:     1: 65.82  4: 62.38  16: 59.30  64: 58.90  256: 61.40  1024: 59.21
                                       (shallow U, ±10% / mostly trial noise)

elastic STEAL_TIMEOUT (µs):  100: 134.13   500: 136.71  2000: 127.02  5000: 131.23  10000: 117.93
                                       (within trial noise; default 10ms is fine for wallclock)
```

None of these knobs move wallclock outside trial-noise. They confirm the bottleneck is downstream of union strategy and scheduler aggressiveness.

## perf — concrete bandwidth and NUMA evidence

`perf stat` on xl T=144 (all-system uncore IMC counters during the ~3.6 s bench):

```
Per-IMC channel (8 channels):  reads 10.4–10.8 GiB,  writes 8.4–8.7 GiB
Aggregate:                     85.0 GiB read + 68.4 GiB write = 153.4 GiB
                               42.3 GiB/s sustained DRAM bandwidth
                               (vs ~240 GB/s aggregate peak: 17.5% of peak)
```

`perf stat -e node-loads,node-load-misses,node-stores,node-store-misses`:

```
node-loads        (local DRAM)        79,440,329       15.4%
node-load-misses  (remote socket)    435,979,810       84.6%
node-stores       (local DRAM)        38,050,297       22.3%
node-store-misses (remote socket)    132,535,547       77.7%
```

`numactl --interleave=all` rerun: remote-load fraction unchanged (84.5%), aggregate DRAM unchanged (45.4 GiB/s — slightly higher because wallclock dropped). Wall median 113 ms vs 134 ms default, but inside trial-jitter (~100 ms cell range).

`perf record` top symbols (xl T=144):

```
25.30%  parlay::scheduler::try_steal           ← workers searching for work
 7.49%  scheduler thread _M_run                ← more scheduler
 6.92%  pe::ConcurrentUnionFind::union_        ← actual work
 5.54%  pe::sigs_equal                         ← actual work
 4.32%  [kernel]
 3.76%  parlay parfor (CanonEntry stage)
 2.76%  libc _int_free
 2.49%  pe::ConcurrentUnionFind::find          ← actual work
```

IPC = 0.53 (Broadwell can do ~3); LLC miss rate 36.96%; branch-miss rate 0.48% (not the issue).

## Bottleneck diagnosis

Three stacked problems, in order of contribution:

1. **Cross-socket interconnect (QPI), not aggregate DRAM.** 84.6% of every load crosses to a remote socket. DRAM channels themselves are at 17% of peak — no per-channel saturation. The penalty is the 3–4× latency premium on remote loads, which collapses IPC to 0.53.

2. **Scheduler starvation, ~33% of cycles.** `try_steal` alone is 25.3%. With 144 workers and fine-grained tasks, most workers spend their time scanning empty deques. Explains the "20% per core" htop visual — those cores are technically busy but doing no work.

3. **Algorithmic randomness in semisort.** `parlay::group_by_key` is hash-partitioned ([src/egraph.cpp:307-309](../../src/egraph.cpp#L307-L309)). Output bucket is independent of input position, so writes scatter across all NUMA nodes regardless of where workers live.

## Why locality is so poor (84.6% remote vs 75% uniform-random floor)

Code-level reasons:

- **Hash-partitioned `group_by_key`** ([src/egraph.cpp:287-326](../../src/egraph.cpp#L287-L326)) — no relationship between input position and output bucket; worker on socket 0 routinely produces output on socket 3.
- **NUMA-blind work-stealing** ([scheduler.h `try_steal`](../../build/_deps/parlaylib-src/include/parlay/scheduler.h)) — victim selection is uniform across all 144 deques. Expected same-socket steal rate is 36/144 = 25%; 75% of stolen jobs run on the wrong socket.
- **Scattered first-touch** ([src/egraph.cpp:140-146](../../src/egraph.cpp#L140-L146)) — `bulk_init` parallel_for spreads pages roughly uniformly across the 4 nodes, but with no affinity to anything.
- **`parlay::allocator` is NUMA-unaware** — thread-local pool, no node pinning.

The extra ~10pp above the 75% uniform-random floor is plausibly `ConcurrentUnionFind` atomic-CAS bounce of dirty cache lines across QPI plus the modest anti-affinity from work-stealing across busy/quiet sockets.

`numactl --interleave=all` doesn't help because data placement was already roughly uniform (IMC counters flat across all 8 channels in both runs).

## Things attempted

- **Elastic STEAL_TIMEOUT sweep (100–10000 µs).** Reduced `try_steal` share from 25.3% → 17.4% at 500 µs and total cycles by 20%, but wallclock unchanged within noise. Saves CPU/power; doesn't lift the throughput ceiling.
- **`numactl --interleave=all`.** No measurable effect on remote-load fraction or wallclock outside noise.
- **DNC cutoff sweep / union_style sweep.** Both within ±10% of each other, all near trial noise.

## Single-socket 192-core projection

The QPI penalty is the dominant addressable cost. On a flat single-socket machine:

```
                  current (144c, 4-sock)        single-socket projection (192c)
                  par@T=144  spd_nel  eff       par@T=192  spd_nel   eff
xl-d3              93 ms     44×    0.18        35–50 ms   80–100×  ~0.40
4xl-d3            329 ms     43×    0.26       150–200 ms  70–90×   ~0.40
2xl-d3            179 ms     36×    0.21        80–100 ms  60–80×   ~0.30
```

Roughly 2× wallclock improvement from NUMA elimination, plus a modest haircut from 33% more cores if scaling holds. Caveats:

- Sub-NUMA (CCX/CCD) on AMD parts will reintroduce intra-socket NUMA penalties — boot with NPS=1 to flatten.
- `try_steal` overhead likely *worsens* at 192 workers (random victim selection over more deques).
- `small`/`medium` will be *worse* — parallel break-even moves further right.

## Artifacts

| File | Contents |
|---|---|
| `system_info.txt` | Host, CPU, memory, toolchain |
| `summary.txt` | Auto-generated summary across all CSVs |
| `strong_scaling.csv` | T=1/16/64/144 × {small, medium, large, deep-s, deep-m, deep-l} |
| `xl.csv`, `xl_deep.csv`, `xl_grid.csv`, `4xl_d3.csv`, `2xl_d3_baseline.csv` | Custom-workload sweeps |
| `components.csv`, `trace.csv`, `smt.csv` | Phase-level + SMT sweeps |
| `union_style.csv`, `dnc_cutoff.csv`, `elastic_sweep.csv` | Tuning sweeps |
| `xl_imc_default.txt`, `xl_imc_interleave.txt` | DRAM bandwidth via IMC counters |
| `xl_node_default.txt`, `xl_node_interleave.txt` | Per-node load/store fractions |
| `xl_perf_stat.txt`, `xl_perf_topsymbols.txt` | perf stat -d -d -d + perf record top symbols |
| `fig_*.png` | Strong-scaling, wallclock, components, trace rounds, SMT |

## What would actually move the needle

- **NUMA-affine semisort** — hash into per-socket buckets first, then within-bucket grouping. Algorithmic change to `merge_and_collect_semisort`.
- **NUMA-aware scheduler** — per-socket deques with same-socket steal preference. Modification to parlay.
- **Per-socket sharding of `ConcurrentUnionFind`'s parent array** — eliminates the atomic-CAS cross-socket bounce.

None of these are reachable from compile flags or environment variables; all require code changes either in this repo or in parlay.
